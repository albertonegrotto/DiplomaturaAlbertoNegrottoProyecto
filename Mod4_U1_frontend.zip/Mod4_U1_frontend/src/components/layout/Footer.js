import React from 'react';

const Footer = (props) =>{
    return (
        <footer className="holder">
             <p>Diseñado por Alberto Negrotto - Módulo 4 Unidad 1 - 2022</p>
        </footer>
    );
}

export default Footer;