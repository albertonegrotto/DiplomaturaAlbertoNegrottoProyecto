import React from "react"

const Header = (props) => {
    return (
        <header>
            <div className="holder">
                <div id="contenedor">
                    <div className="izquierdo">
                        <img src="images/LogoBusIT.jpg" width="100" alt="Busquedas IT" />
                        <h1>Búsquedas IT</h1>
                    </div>
                    <div className="derecho">
                        <ul>
                            <li><a href="https://www.facebook.com/busquedasit/" target="_blank" rel="noreferrer"
                                title="Seguinos en Facebook"><img src="images/logoacebook.jpg" /></a>
                            </li>
                            <li><a href="https://www.facebook.com/busquedasit/" target="_blank" rel="noreferrer"
                                title="Seguinos en Facebook"><img src="images/logoacebook.jpg" /></a>
                            </li>
                            <li><a href="https://www.instagram.com/busquedasit_arg/" target="_blank" rel="noreferrer"
                                title="Nuestro Instagram"><img src="images/logoInstagram.jpg" /></a>
                            </li>
                            <li><a href="https://twitter.com/busquedasit_arg/" target="_blank" rel="noreferrer"
                                title="Seguinos en Twitter"><img src="images/logoTwitter.jpg" /></a>
                            </li>
                            <li><a href="https://www.youtube.com/channel/UCtMHAAu6xiF-4ZCHvfYo4pA" rel="noreferrer"
                                target="_blank" title="Seguinos en Youtube"><img src="images/logoyoutube.jpg" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
    );
}

export default Header;